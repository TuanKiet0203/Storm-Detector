#ifndef INC_ERA_WIRE_WIRING_PI_HPP_
#define INC_ERA_WIRE_WIRING_PI_HPP_

#include <Utility/ERaI2CWiringPi.hpp>

#endif /* INC_ERA_WIRE_WIRING_PI_HPP_ */
