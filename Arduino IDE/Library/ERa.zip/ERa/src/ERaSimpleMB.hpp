#ifndef INC_ERA_SIMPLE_MODBUS_HPP_
#define INC_ERA_SIMPLE_MODBUS_HPP_

#define ERA_MODBUS

#include <ERaSimple.hpp>

#endif /* INC_ERA_SIMPLE_MODBUS_HPP_ */
