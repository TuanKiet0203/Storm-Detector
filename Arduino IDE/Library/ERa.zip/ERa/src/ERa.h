#ifndef INC_ERA_H_
#define INC_ERA_H_

#if !defined(ERA_TURN_OFF_WARNING)
    #warning "Please include a board-specific header file!"
#endif

#endif /* INC_ERA_H_ */
