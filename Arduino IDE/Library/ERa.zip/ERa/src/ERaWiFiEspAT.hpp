#ifndef INC_ERA_WIFI_ESP_AT_HPP_
#define INC_ERA_WIFI_ESP_AT_HPP_

#define ERA_MODBUS

#include <ERaSimpleWiFiEspAT.hpp>

#endif /* INC_ERA_WIFI_ESP_AT_HPP_ */
