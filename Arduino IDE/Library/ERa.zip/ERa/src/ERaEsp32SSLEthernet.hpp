#ifndef INC_ERA_ESP32_SSL_ETHERNET_HPP_
#define INC_ERA_ESP32_SSL_ETHERNET_HPP_

#define ERA_MODBUS
#define ERA_ZIGBEE

#include <ERaSimpleEsp32SSLEthernet.hpp>

#endif /* INC_ERA_ESP32_SSL_ETHERNET_HPP_ */
