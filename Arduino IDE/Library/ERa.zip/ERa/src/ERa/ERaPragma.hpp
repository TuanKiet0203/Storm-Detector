#ifndef INC_ERA_PRAGMA_HPP_
#define INC_ERA_PRAGMA_HPP_

#if defined(ERA_BOARD_TYPE)
    #pragma message ("Board Info: " ERA_TOSTRING(ERA_BOARD_TYPE))
#endif

#endif
